"use strict";
exports.__esModule = true;
var Customer = /** @class */ (function () {
    function Customer(firstName, lastName, age) {
        this.getAge = function () {
            console.log(this.age);
            return this.age;
        };
        this.getLastName = function () {
            return this.lastName;
        };
        this.getFirstName = function () {
            return this.firstName;
        };
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }
    Customer.prototype.greeter = function () {
        console.log("Hello " + this.firstName + " " + this.lastName);
    };
    return Customer;
}());
exports.Customer = Customer;
;
