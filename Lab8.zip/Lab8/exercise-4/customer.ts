export class Customer{
    private firstName: String;
    private lastName: String;
    private age;

    constructor(firstName: string, lastName: string, age){
        this.firstName=firstName;
        this.lastName=lastName;
        this.age = age;
    }

    getAge =function(){
        console.log(this.age);
        return this.age;
    }

    getLastName = function():String{
        return this.lastName;
        
    };
    getFirstName = function():String{
       return this.firstName;
   };
   public greeter(){
      console.log(`Hello ${this.firstName} ${this.lastName}`);
   }

};
 
