class Customer{
     private firstName: String;
     private lastName: String;

     setFirstName = function(first):void{
        this.firstName=first;
     };
     setLastName = function(last):void{
        this.lastName = last;
     };

     getLastName = function():String{
         return this.lastName;
         
     };
     getFirstName = function():String{
        return this.firstName;
    };
    public greeter(){
       console.log(`Hello ${this.firstName} ${this.lastName}`);
    }

};
  
let customer = new Customer();
customer.setFirstName("John");
customer.setLastName("Smith");
customer.greeter();



