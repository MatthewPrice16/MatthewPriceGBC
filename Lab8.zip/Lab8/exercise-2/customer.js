var Customer = /** @class */ (function () {
    function Customer() {
        this.setFirstName = function (first) {
            this.firstName = first;
        };
        this.setLastName = function (last) {
            this.lastName = last;
        };
        this.getLastName = function () {
            return this.lastName;
        };
        this.getFirstName = function () {
            return this.firstName;
        };
    }
    Customer.prototype.greeter = function () {
        console.log("Hello " + this.firstName + " " + this.lastName);
    };
    return Customer;
}());
;
var customer = new Customer();
customer.setFirstName("John");
customer.setLastName("Smith");
customer.greeter();
