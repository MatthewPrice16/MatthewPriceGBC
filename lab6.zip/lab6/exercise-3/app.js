var express = require('express');
var app = express();
var mongoose = require('mongoose');

 mongoose.connect('mongodb://blank327:Pizza97@ds127843.mlab.com:27843/dbtest1');

 var port = process.env.PORT || 3000;
 app.listen(port);

var Schema = mongoose.Schema;
var userSchema = new Schema({name: String, status: String});
var User = mongoose.model('User',userSchema);
var John = User({name: 'John',status: 'active'});
var Jane = User({name: 'Jane',status: 'active'});

John.save(function(err){
    if(err) throw err;

    console.log('****User Saved****');

});
Jane.save(function(err){
    if(err) throw err;

    console.log('****User Saved****');

});

