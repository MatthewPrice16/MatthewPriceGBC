import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DirectiveNormalizer } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class IssueService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

  getIssues(){
    return this.http.get(`${this.uri}/issues`);
  }

  getIssueByID(id) {
    return this.http.get(`${this.uri}/issues/${id}`);
  }
  getIssueByTitle(title) {
    return this.http.get(`${this.uri}/issues/${title}`)
  }
  addIssue(title, runtime, genre, rating, director,status){
    const issue = {
      title: title,
      runtime: runtime,
      genre: genre,
      rating: rating,
      director: director,
      status: status
    };
    return this.http.post(`${this.uri}/issues/add`,issue);
  }
  updateIssue(id, title, runtime, genre, rating, director, status){
    const issue = {
      title: title,
      runtime: runtime,
      genre: genre,
      rating: rating,
      director: director,
      status: status
    };
    return this.http.post(`${this.uri}/issues/update/${id}`,issue);
  }

  deleteIssue(id){
    return this.http.get(`${this.uri}/issues/delete/${id}`);
  }
}
