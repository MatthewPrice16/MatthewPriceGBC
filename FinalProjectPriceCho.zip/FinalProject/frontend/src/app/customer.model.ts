export interface Customer{
    id: String;
    firstname: String;
    lastname: String;
    address: String;
    city: String;
    phonenumber: String;
    status: String;
    movies: Array<String>;
}