import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DirectiveNormalizer } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

 
  getAdminByUser(user) {
    return this.http.get(`${this.uri}/admin/${user}`);
  }
 
 
}
