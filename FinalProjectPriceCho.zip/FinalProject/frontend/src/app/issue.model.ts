export interface Issue{
    id: String;
    title: String;
    runtime: String;
    genre: String;
    rating: String;
    director: String;
    status: String;
}
