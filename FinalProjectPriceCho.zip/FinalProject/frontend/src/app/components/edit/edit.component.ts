import { Component, OnInit } from '@angular/core';
import { IssueService } from '../../issue.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar} from '@angular/material';
import { Issue } from '../../issue.model';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  id: String;
  issue: any = {};
  updateForm: FormGroup;

  constructor(private issueService: IssueService, private router:Router,private route:ActivatedRoute,private snackbar:MatSnackBar,private fb:FormBuilder) { 
    this.createForm();
  }

  createForm(){
    this.updateForm = this.fb.group({
      title: ['',Validators.required],
      runtime: '',
      genre: ['',Validators.required],
      rating: '',
      director: '',
      status: ['',Validators.required]
    });
  }


  ngOnInit() {

    this.route.params.subscribe(params =>{
      if(sessionStorage.getItem("valid")==="false"||sessionStorage.getItem("valid") === null){
        this.router.navigate(['login']);
      }
      else
      this.id = params.id;
      this.issueService.getIssueByID(this.id).subscribe(res=>{
        this.issue = res;
        this.updateForm.get('title').setValue(this.issue.title);
        this.updateForm.get('runtime').setValue(this.issue.runtime);
        this.updateForm.get('genre').setValue(this.issue.genre);
        this.updateForm.get('rating').setValue(this.issue.rating);
        this.updateForm.get('director').setValue(this.issue.director);
        this.updateForm.get('status').setValue(this.issue.status);
      });
    });
  }

  updateIssue(title,runtime,genre,rating,director,status){
    this.issueService.updateIssue(this.id,title,runtime,genre,rating,director,status).subscribe(()=>{
      this.snackbar.open('Video updated successfully','OK',{
        duration: 3000
      });
    });
  }

}
