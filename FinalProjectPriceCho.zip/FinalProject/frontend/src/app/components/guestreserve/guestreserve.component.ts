import { Component, OnInit } from '@angular/core';
import { IssueService } from '../../issue.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar} from '@angular/material';
import { Issue } from '../../issue.model';
import { Customer } from '../../customer.model';
import { CustomerService } from '../../customer.service';
import { delay } from 'q';



@Component({
  selector: 'app-guestreserve',
  templateUrl: './guestreserve.component.html',
  styleUrls: ['./guestreserve.component.css']
})
export class GuestreserveComponent implements OnInit {
  
  id: String;
  customers:Customer[] = [];
  issue: any = {};
  updateForm: FormGroup;

  title:String;
  runtime: String;
  genre:String;
  rating:String;
  director:String;
  status:String;

  constructor(private issueService: IssueService, private router:Router,private route:ActivatedRoute,private snackbar:MatSnackBar,private fb:FormBuilder,private customerService: CustomerService) {
    this.createForm();
   }

  ngOnInit() {
    this.fetchCustomers();
    this.getIssue();
    //setTimeout(
      //function () {
        //for(let i=0;i<this.customers.length;i++){
          //this.custnames.push(this.customers[i].firstname);
          //console.log(this.custnames[i]); }}, 5000);
         
  }
  fetchCustomers(){
    this.customerService.getCustomer().subscribe((data: Customer[])=>{
      this.customers = data;
      console.log('Data requested...');
      console.log(this.customers);
    });
  }
  getIssue(){
    this.route.params.subscribe(paramsId => {
      this.id = paramsId.id;
      this.issueService.getIssueByID(this.id).subscribe(res=>{
        this.issue = res;
        this.title = this.issue.title;
        this.runtime = this.issue.runtime;
        this.genre = this.issue.genre;
        this.rating = this.issue.rating;
        this.director = this.issue.title;
        this.updateForm.get('status').setValue(this.issue.status);
      });
  });

  }
  letsGo(){

  }

  createForm(){
    this.updateForm = this.fb.group({
      title: ['',Validators.required],
      runtime: '',
      genre: ['',Validators.required],
      rating: '',
      director: '',
      status: ['',Validators.required]
    });
  }
}
