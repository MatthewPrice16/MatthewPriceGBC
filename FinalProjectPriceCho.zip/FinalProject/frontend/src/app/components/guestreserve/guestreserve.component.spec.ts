import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestreserveComponent } from './guestreserve.component';

describe('GuestreserveComponent', () => {
  let component: GuestreserveComponent;
  let fixture: ComponentFixture<GuestreserveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuestreserveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestreserveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
