import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { Customer } from '../../customer.model';
import { CustomerService } from '../../customer.service';
import { FormsModule } from '@angular/forms';
import { fromEventPattern } from 'rxjs';
import { IssueService } from 'src/app/issue.service';

@Component({
  selector: 'app-guestlist',
  templateUrl: './guestlist.component.html',
  styleUrls: ['./guestlist.component.css']
})
export class GuestlistComponent implements OnInit {

  customers:Customer[];
  searchCust: String;
  displayedColumns = ['firstname','lastname','address','city','phonenumber','status'];

  constructor(private customerService: CustomerService, private router: Router) { }

  ngOnInit() {
    if(sessionStorage.getItem("valid")==="false"||sessionStorage.getItem("valid") === null){
      this.router.navigate(['login']);
    }
    else{
      this.fetchCustomers();
    }
  }

  getByName(firstname) {
    this.customerService.getByFirst(firstname).subscribe(() =>{
      this.fetchCustomers();
    });
  }

  fetchCustomers(){
    this.customerService.getCustomer().subscribe((data: Customer[])=>{
      this.customers = data;
      console.log('Data requested...');
      console.log(this.customers);
    });
    
  }
  Logout(){
    sessionStorage.setItem("valid","false");
    this.router.navigate(['login']);

  }

}
