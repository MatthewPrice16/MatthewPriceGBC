import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../admin.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Admin } from '../../admin.model';
import { MatSnackBar} from '@angular/material';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  admin:Admin[];
  userDb: String;
  passwordDb: String;
  user: String;
  password: String;
  loginForm : FormGroup;
  

  constructor(private adminService: AdminService, private fb: FormBuilder, private router:Router,private snackbar:MatSnackBar) { 
      this.loginForm = this.fb.group({
      user: ['',Validators.required],
      password: ['',Validators.required],
    
    });
  }
  Login(){
    this.user = this.loginForm.controls['user'].value;
    this.password = this.loginForm.controls['password'].value;
    //check db for user and return the object associated with that user
    this.adminService.getAdminByUser("5c0df1f3ceba2620c4ed14b5").subscribe((data: JSON)=>{
      this.userDb = data["login"];
      this.passwordDb = data["password"];
    if(this.userDb === this.user && this.passwordDb === this.password){
      sessionStorage.setItem('valid', "true");
      this.router.navigate(['list'])
    }
    else{
      this.snackbar.open('Incorrect Username or Password','OK',{
        duration: 3000
      });
      sessionStorage.setItem('valid', "false");
      this.router.navigate([`login`]);
    } 
  });  
  }

  ngOnInit() {
    if(sessionStorage.getItem("valid")==="true"){
      this.router.navigate(['list']);
    }
    
  }

}
