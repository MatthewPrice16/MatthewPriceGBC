import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { Issue } from '../../issue.model';
import { IssueService } from '../../issue.service';
import { FormsModule } from '@angular/forms';
import { fromEventPattern } from 'rxjs';

@Component({
  selector: 'app-publiclist',
  templateUrl: './publiclist.component.html',
  styleUrls: ['./publiclist.component.css']
})

export class PubliclistComponent implements OnInit {

  issues:Issue[];
  //displayedColumns = ['title', 'runtime', 'genre', 'rating', 'director', 'status', 'actions'];
  //videoTitle = new FormControl();
  public searchTitle : string;
  //public videos: any;
  displayedColumns = ['title','runtime','genre','rating','director','status','reserve'];

  constructor(private issueService: IssueService, private router: Router) { }

  ngOnInit() {
    this.searchTitle;
  }

  getIssueByTitle(firstname) {
    this.issueService.getIssueByTitle(firstname).subscribe(() =>{
      this.fetchIssues();
    });
  }

  fetchIssues(){
    this.issueService.getIssues().subscribe((data: Issue[])=>{
      this.issues = data;
      console.log('Data requested...');
      console.log(this.issues);
    });
  }
  reserveIssue(id){
    this.router.navigate([`/reserve/${id}`]);
  }

}
