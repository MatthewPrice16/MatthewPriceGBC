import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DirectiveNormalizer } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

  getCustomer(){
    return this.http.get(`${this.uri}/customer/all`);
  }
  getByFirst(firstname){
    return this.http.get(`${this.uri}/customer/${firstname}`);
  }
  addCustomer(firstname, lastname, address, city, phonenumber, status){
    const customer = {
      firstname: firstname,
      lastname: lastname,
      address: address,
      city: city,
      phonenumber: phonenumber,
      status: status
      
    };
    return this.http.post(`${this.uri}/customer/add`,customer);
  }

 
}