export interface Admin{
    login: String;
    password: String;
}