import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { MatToolbarModule, MatFormFieldModule, MatInputModule, MatOptionModule, MatSelectModule, MatIconModule, MatButtonModule, MatCardModule, MatDividerModule, MatSnackBarModule, MatTableModule } from '@angular/material';
import { IssueService } from './issue.service';
import { AdminService } from './admin.service';
import { CustomerService } from './customer.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ListComponent } from './components/list/list.component';

import { tblFilterPipe } from './tblFilter.pipe';
import { CreateComponent } from './components/create/create.component';
import { EditComponent } from './components/edit/edit.component';
import { LoginComponent } from './components/login/login.component';
import { GuestlistComponent } from './components/guestlist/guestlist.component';
import { GuestreserveComponent } from './components/guestreserve/guestreserve.component';
import { PubliclistComponent } from './components/publiclist/publiclist.component';

const routes: Routes = [
  { path: 'create', component: CreateComponent},
  { path: 'edit/:id', component: EditComponent},
  { path: 'list', component: ListComponent},
  { path: 'login', component: LoginComponent},
  { path: 'reserve/:id', component: GuestreserveComponent},
  { path: 'admin/:user', component: LoginComponent},
  { path: 'guestlist', component: GuestlistComponent},
  { path: 'publiclist', component: PubliclistComponent},
  { path: '', redirectTo: 'publiclist', pathMatch: 'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    CreateComponent,
    EditComponent,
    LoginComponent,
    GuestlistComponent,
    GuestreserveComponent,
    PubliclistComponent,
    tblFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    MatToolbarModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatOptionModule, 
    MatSelectModule, 
    MatIconModule, 
    MatButtonModule,
    MatCardModule, 
    MatTableModule,
    MatDividerModule,
    ReactiveFormsModule, 
    MatSnackBarModule,
    FormsModule
  ],
  providers: [IssueService,AdminService,CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
