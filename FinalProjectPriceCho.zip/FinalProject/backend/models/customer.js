import mongoose from 'mongoose';
const Schema = mongoose.Schema;

let Customer = new Schema({
    firstname: {
        type: String
    },
    lastname: {
        type: String
    },
    address: {
        type: String
    },
    city: {
        type: String
    },
    phonenumber: {
        type: String
    },
    status: {
        type: String,
        default: 'Active'
    },
    movies: {
        type: Array
    }
});
export default mongoose.model('Customer',Customer);