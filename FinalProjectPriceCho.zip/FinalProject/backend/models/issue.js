import mongoose from 'mongoose';
const Schema = mongoose.Schema;

let Issue = new Schema({
    title: {
        type: String
    },
    runtime: {
        type: String
    },
    genre: {
        type: String
    },
    rating : {
        type: String
    },
    director: {
        type: String
    },
    status: {
        type: String,
        default: 'Availible'
    }
});
export default mongoose.model('Issue',Issue);