const say = require('say');
var sorry = require('./sorryDave')
//use default system voice to say hello
//say.speak('Hello!');

//stop text currently being said
//say.stop();

//slower speed more complex

sorryDave = function(callback){
    callback(); 
    say.speak('I am sorry dave','Dave',1);
    
}
say.speak('Hello','alex',0.5);

say.speak(sorryDave(setTimeout));


