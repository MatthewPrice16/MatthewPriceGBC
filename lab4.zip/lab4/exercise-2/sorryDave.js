const say = require('say');

var sorryDave = function(callback){
    say.speak('I am sorry dave','Dave',1);
    callback(); 
}
module.exports = sorryDave();
