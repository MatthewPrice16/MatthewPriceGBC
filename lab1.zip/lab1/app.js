var moment2 = require('moment');
console.log(moment2);