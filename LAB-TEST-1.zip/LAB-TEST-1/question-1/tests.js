var calc = require('./calculator');
var should = require('should');
