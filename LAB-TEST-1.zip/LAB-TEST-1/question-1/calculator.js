

var multiplyTwoNumbers=function(x,y){
    if(Number.isInteger(x)==false &&Number.isInteger(y)==false){
        notint = new Error('error not an integer');
        return notint;
    }
return x*y;
}

var evenDoubler = function(x){
    if(Number.isInteger(x)===false){
        notint = new Error('error not an integer');
        return notint;
        
    }
    else if(x%2 == 0){
        return x*x;
    }
    return 0;
}

module.exports = {
    multiplyTwoNumbers: multiplyTwoNumbers,
    evenDoubler: evenDoubler
}

