var calc = require('./calculator');


//console.log(calc.multiplyTwoNumbers(6,'he'));
//console.log(calc.evenDoubler('hello'));
var x = 6;
var y =6;
var z = 4;

console.log('Multiply '+x + ' * '+y +' equals: ' +calc.multiplyTwoNumbers(x,y));
console.log('even doubler '+z+ ' equals: '+calc.evenDoubler(z));