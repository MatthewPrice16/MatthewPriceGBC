var firewall = require('./osinfo/firewall');
var systeminfo = require('./osinfo/systeminfo');
var os = require('os');


const http = require('http');
const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req,res)=>{
    
    
    res.statusCode = 200;
    res.setHeader('Content-Type','text/plain');
    res.end('Hello World\n');

    if(req.url === '/'){
        res.statusCode = 200;

        res.setHeader('Content-Type','application/json');
        res.end('No data found.\n');
    }
    else if(req.url === '/api/systeminfo'){
        res.statusCode = 200;

        res.setHeader('Content-Type','application/systeminfo');
        res.end(systeminfo.getSysteminfo(os.cpus,os.hostname,os.type));

    }
    else if(req.url === '/api/userinfo'){
        res.statusCode = 200;

        res.setHeader('Content-Type','application/systeminfo');
        res.end(systeminfo.getUserinfo(os.userInfo,os.userInfo().username,os.homedir));

    }
    else if(req.url === '/api/firewall'){
        res.statusCode = 200;

        res.setHeader('Content-Type','application/firewall');
        res.end(firewall.getStatuses());

    }

    
});


server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });