var getStatuses = function(){
    var a = ["OK", "ALLOW", "DENY","BLOCK"];
    return a;
}
module.exports = {
    getStatuses:getStatuses
}