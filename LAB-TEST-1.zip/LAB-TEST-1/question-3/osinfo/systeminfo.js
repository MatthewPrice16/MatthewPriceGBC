var getSysteminfo = function(cpu,hostName,osName){
var s = "";
 s = s+cpu + " "+hostName + " "+osName;
 return s;
}
var getUserinfo = function(userInfo,username,homeDir){
    var s = "";
     s = s+userInfo + " "+username + " "+homeDir;
     return s;
    }

    module.exports = {
        getSysteminfo: getSysteminfo,
        getUserinfo: getUserinfo
    }
    