//require built in file system module
var fs = require('fs');


//create readable stream to file
var stream = fs.createReadStream("data.txt");
var file = fs.createWriteStream('output.txt');

//subscribe to 'data' emitter in readable stream
stream.on("data", function(data){
console.log(data);
console.log(data.toString());
file.write(data.toString());
})

stream.on("end",function(end){
    stream.close;
    console.log('\n The write is complete');
})