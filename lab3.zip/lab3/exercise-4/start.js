

var handleCounter = function(result){
    console.log('The callback count is: '+ result);
}

var callbackLoop = function(x,callback){
i = 0;
while(i!=x){
    i++;
    callback(i);
}
console.log('***exiting callbackloop***')

}

callbackLoop(5,handleCounter);
