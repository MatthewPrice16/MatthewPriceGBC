

var max = 50;



var handleCounter = function(err,counter,waitTime,timeStamp){

    if(err){
        console.log('you have an error: '+err);
        return;
    }
    console.log('Count: '+counter +' WaitTime: '+waitTime+' timeStamp: '+timeStamp);

}

var callbackWait = function(counter,callback){
    var randWait = Math.floor(Math.random()*(max+counter));
    var timeS = new Date (Date.now()).toLocaleString();
    if(randWait> max){
        tooBig = new Error('Wait time is greater than the max time');
        callback(tooBig);
        return;

    }
    setTimeout(function () {
        callback(null,counter,randWait,timeS);
    },randWait);
    
}

for (var i=0;i<10;i++){
    callbackWait(i,handleCounter);
}