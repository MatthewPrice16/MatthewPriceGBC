//require built in file system module
var fs = require('fs');

//create readable stream to file
var stream = fs.createReadStream("data.txt");

//subscribe to 'data' emitter in readable stream
stream.on("data", function(data){
console.log(data);
console.log(data.toString());

})
