const fs = require('fs');

const file = fs.createWriteStream('./writer.txt');

var writeData = function(){
    for (let i=0; i<=10; i++){
        file.write('some text to write\n');
    }
    file.end();
}
module.exports = {
    writeData: writeData
}
