const fs = require('fs');
var writer = require('./writer');

writer.writeData();